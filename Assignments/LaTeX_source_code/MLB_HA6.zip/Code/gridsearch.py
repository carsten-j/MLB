param_grid = {
    "estimator__max_depth": [1, 2, 3],
    "n_estimators": [50, 100, 200],
}

# Create base classifier (Decision Tree with Gini impurity)
base_classifier = DecisionTreeClassifier(criterion="gini", random_state=42)

# Create AdaBoost classifier with SAMME algorithm
ada_boost = AdaBoostClassifier(estimator=base_classifier, algorithm="SAMME", random_state=42)

# Set up 2-fold cross validation
cv = StratifiedKFold(n_splits=2, shuffle=True, random_state=42)

# Perform grid search
print("Performing grid search with 2-fold cross validation...")
grid_search = GridSearchCV(estimator=ada_boost, param_grid=param_grid, cv=cv, scoring="accuracy", n_jobs=-1, verbose=1)

# Fit grid search
grid_search.fit(X_train_central, y_train_flat)