eval_metric = "rmse"

xgb_ref = XGBRegressor(
    objective="reg:squarederror",
    # parameters specified by the exercise
    colsample_bytree=0.5,
    learning_rate=0.1,
    max_depth=4,
    reg_lambda=1.0,
    n_estimators=500,
    eval_metric=eval_metric,
    # nice-to-have settings
    random_state=RANDOM_STATE,
    verbosity=0,
)

eval_set = [(X_tr, y_tr), (X_val, y_val)]

xgb_ref.fit(X_tr, y_tr, eval_set=eval_set, verbose=False)

# --- Plot RMSE vs. boosting iteration -----------------------
results = xgb_ref.evals_result()
rmse_tr = results["validation_0"][eval_metric]
rmse_va = results["validation_1"][eval_metric]

# --- Evaluate on the *held-out* test set ---------------------
y_pred_ref = xgb_ref.predict(X_test)
rmse_ref = root_mean_squared_error(y_test, y_pred_ref)
r2_ref = r2_score(y_test, y_pred_ref)

# ------------------------------------------------------------
# Step 3.  Hyper-parameter grid search (3-fold CV) plus KNN = 5
# ------------------------------------------------------------
param_grid = {
    "colsample_bytree": [0.5, 0.6],
    "learning_rate": [0.001, 0.01, 0.02],
    "max_depth": [8, 9, 10],
    "n_estimators": [400, 500],
    "reg_lambda": [1.5, 1.6],
}

xgb_base = XGBRegressor(
    objective="reg:squarederror", random_state=RANDOM_STATE, verbosity=0
)

grid = GridSearchCV(estimator=xgb_base, param_grid=param_grid,
    cv=3, scoring="neg_root_mean_squared_error", n_jobs=-1,
    verbose=1)

grid.fit(X_train, y_train)  # ONLY on *training* part

best_params = grid.best_params_
best_rmse = -grid.best_score_  # negate again

# ---- Train final XGBoost with the discovered configuration --
xgb_best = XGBRegressor(
    objective="reg:squarederror", random_state=RANDOM_STATE, verbosity=0, **best_params
)
xgb_best.fit(X_train, y_train)

y_pred_best = xgb_best.predict(X_test)
rmse_best = root_mean_squared_error(y_test, y_pred_best)
r2_best = r2_score(y_test, y_pred_best)

# ---- Baseline: 5-nearest-neighbours regressor ------------
knn = KNeighborsRegressor(n_neighbors=5)
knn.fit(X_train, y_train)
y_pred_knn = knn.predict(X_test)
rmse_knn = root_mean_squared_error(y_test, y_pred_knn)
r2_knn = r2_score(y_test, y_pred_knn)