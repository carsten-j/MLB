# helpers for Eq. (8) & bound. KL divergence is computed
# in log-domain using the first equality in Eq. (9)
KL = np.sum(rho * (log_rho - log_pi))
L_emp = np.dot(rho, L_val)