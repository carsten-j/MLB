# Build ensemble of m weak SVMs  (Sec. 5 construction
# of Hypothesis Space H)
for i in range(m):
    # Select r = d + 1 random indices for training
    # and the rest for validation
    train_idx = rng.choice(n, r, replace=False)
    val_idx = np.setdiff1d(all_indices, train_idx, assume_unique=True)

    X_tr, y_tr = X_S[train_idx], y_S[train_idx]
    X_val, y_val = X_S[val_idx], y_S[val_idx]

    # Select random gamma from grid - p. 10 in paper
    gamma = rng.choice(gamma_grid)
    clf = SVC(kernel="rbf", C=1.0, gamma=gamma).fit(X_tr, y_tr)

    L_val[i] = zero_one_loss(clf.predict(X_val), y_val)
    predsT[i] = clf.predict(X_T)

rho, _, bound = minimize_bound(L_val)

# rho-weighted Majority vote of Eq. (3.31)
# in Machine Learning: The science of selection under uncertainty
mv_raw = rho @ predsT
mv_pred = np.sign(mv_raw)  # +/- 1  (np.sign(0) returns 0 - no tie here)
