# Eq. (7): computed in log-domain for numerical stability
log_pi = -np.log(m) * np.ones(m) # uniform prior \pi(h)=1/m (p. 10)
log_rho = log_pi - lambda_ * n_r * L_val
log_rho -= logsumexp(log_rho)
rho = np.exp(log_rho)