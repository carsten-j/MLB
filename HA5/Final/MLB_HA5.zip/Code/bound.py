# Eq. (13): value of PAC-Bayes-\lambda bound 
bound = L_emp / (1 - lambda_ / 2.0) + (KL + np.log(2 * np.sqrt(n_r) / delta)) / (
    n_r * lambda_ * (1 - lambda_ / 2.0)
)