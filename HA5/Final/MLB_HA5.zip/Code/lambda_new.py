# Eq. (8): lambda_new
num = 2.0
denom = (
    np.sqrt(2.0 * n_r * L_emp / (KL + np.log(2 * np.sqrt(n_r) / delta)))
    + 1.0
    + 1.0
)
lambda_new = num / denom